import java.util.ArrayList;
import java.util.List;

public class Game {
    private boolean juegoTerminado;

    private GamePrinter gamePrinter;

    private List<Jugador> jugadores = new ArrayList<Jugador> ();

    public boolean jugadorPuedeColocar() {
    }

    public boolean cumpleReglas() {
    }

    public void obtenerPuntuacion() {
    }

    public void anadirFicha() {
    }

    public boolean getJuegoTerminado() {
    }

    public Game() {
    }

}
