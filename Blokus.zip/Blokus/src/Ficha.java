import java.util.ArrayList;
import java.util.List;

public class Ficha {
    private String equipo;

    private int[] forma;

    private List<Casilla> arrayCasillas = new ArrayList<Casilla> ();

    public void rotar(int rotacion) {
    }

    public void setForma() {
    }

    public Ficha(List<Integer> forma, List<Casilla> arrayCasillas) {
    }

}
