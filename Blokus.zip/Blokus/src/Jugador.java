import java.util.ArrayList;
import java.util.List;

public class Jugador {
    private int puntuacion;

    private List<Ficha> arrayFichas = new ArrayList<Ficha> ();

    public int getPuntuacion() {
    }

    public void borrarPieza(int pieza) {
    }

    public boolean puedeJugar() {
    }

    public Jugador(List<Ficha> arrayFichas) {
    }

}
