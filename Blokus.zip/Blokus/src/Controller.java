
public class Controller {
    private Game game;

    public Command command;

    public void run() {
    }

    public Controller(Game game) {
    }

}
