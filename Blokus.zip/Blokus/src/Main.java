
public class Main {
    private Controller controller;

    public void main() {
    }

}
