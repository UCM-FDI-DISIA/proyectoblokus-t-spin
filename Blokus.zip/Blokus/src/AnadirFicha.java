
public class AnadirFicha extends Command {
    private String nombre;

    private String abreviacion;

    public Command parse(String palabras) {
    }

    public boolean ejecutar(Game game) {
    }

    public AnadirFicha() {
    }

}
