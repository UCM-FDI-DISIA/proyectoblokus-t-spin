
public class CommandGenerator {
    private Command comandos;

    public Command parse(String palabras) {
    }

}
