
public class Casilla {
    private int x;

    private int y;

    public Casilla(int x, int y) {
    }

}
