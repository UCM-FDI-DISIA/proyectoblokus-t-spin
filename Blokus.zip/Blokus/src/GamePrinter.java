
public class GamePrinter {
    private Game game;

    public String dibujar() {
    }

    public String toString() {
    }

    public GamePrinter(Game game) {
    }

}
